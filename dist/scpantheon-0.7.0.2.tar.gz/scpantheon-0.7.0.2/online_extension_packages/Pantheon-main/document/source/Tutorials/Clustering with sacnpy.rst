Clustering with sacnpy
======================