Clustering with scanpy
======================