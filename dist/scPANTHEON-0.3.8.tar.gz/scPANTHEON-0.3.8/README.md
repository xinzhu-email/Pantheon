# Pantheon
## Download
Run in command line: pip install scpantheon

## Run Pantheon
Run in command line: sc-pantheon

## Tutorial
[See here](https://pantheon.readthedocs.io/en/latest/index.html)

## Sponsor
[万乘基因-10K Genomics](http://www.10kgenomics.com/)

![本地路径](10k-genomics.png "万乘基因")
